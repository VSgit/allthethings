The icons svg you choose for the --set-icons option will be saved to this folder.
